# Create Docker configuration files
dockerfile_sidecar = '''# Dockerfile for ML Sidecar API
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    gcc \\
    g++ \\
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir --upgrade pip
RUN pip install --no-cache-dir -r requirements.txt

# Copy source code
COPY src/ ./src/
COPY model/ ./model/
COPY data/ ./data/
COPY config/ ./config/

# Create necessary directories
RUN mkdir -p logs model/final data

# Set environment variables
ENV PYTHONPATH=/app/src
ENV WAF_LOG_LEVEL=INFO
ENV WAF_MODEL_PATH=/app/model/final/detector.json

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \\
    CMD curl -f http://localhost:8080/health || exit 1

# Expose port
EXPOSE 8080

# Run the application
CMD ["python", "src/server.py", "--host", "0.0.0.0", "--port", "8080"]
'''

with open("webapp-ml-waf/docker/Dockerfile.sidecar", "w") as f:
    f.write(dockerfile_sidecar)

# Create OpenResty/Nginx Dockerfile
dockerfile_nginx = '''# Dockerfile for OpenResty WAF
FROM openresty/openresty:alpine

# Install required modules
RUN /usr/local/openresty/luajit/bin/luarocks install lua-resty-http

# Copy configuration
COPY config/nginx.conf /usr/local/openresty/nginx/conf/nginx.conf
COPY config/waf.lua /usr/local/openresty/site/lualib/waf.lua

# Create log directory
RUN mkdir -p /var/log/waf && chown nginx:nginx /var/log/waf

# Health check
HEALTHCHECK --interval=30s --timeout=5s --start-period=10s --retries=3 \\
    CMD curl -f http://localhost/health || exit 1

# Expose ports
EXPOSE 80 443

CMD ["/usr/local/openresty/bin/openresty", "-g", "daemon off;"]
'''

with open("webapp-ml-waf/docker/Dockerfile.nginx", "w") as f:
    f.write(dockerfile_nginx)

# Create Docker Compose configuration
docker_compose = '''version: '3.8'

services:
  # ML Sidecar API
  ml-sidecar:
    build:
      context: .
      dockerfile: docker/Dockerfile.sidecar
    container_name: waf-ml-sidecar
    ports:
      - "8080:8080"
    volumes:
      - ./data:/app/data
      - ./model:/app/model
      - ./logs:/app/logs
      - ./config:/app/config
    environment:
      - WAF_LOG_LEVEL=INFO
      - WAF_ANOMALY_THRESHOLD=0.5
      - PYTHONPATH=/app/src
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
    restart: unless-stopped
    networks:
      - waf-network

  # OpenResty WAF Gateway
  waf-gateway:
    build:
      context: .
      dockerfile: docker/Dockerfile.nginx
    container_name: waf-nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./config/nginx.conf:/usr/local/openresty/nginx/conf/nginx.conf:ro
      - ./logs:/var/log/waf
    depends_on:
      ml-sidecar:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost/health"]
      interval: 30s
      timeout: 5s
      retries: 3
    restart: unless-stopped
    networks:
      - waf-network

  # Sample Web Application (for demo)
  sample-app:
    image: nginx:alpine
    container_name: sample-web-app
    ports:
      - "8081:80"
    volumes:
      - ./demo/sample-app:/usr/share/nginx/html:ro
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost"]
      interval: 30s
      timeout: 5s
      retries: 3
    restart: unless-stopped
    networks:
      - waf-network

  # Optional: Monitoring with Prometheus
  prometheus:
    image: prom/prometheus:latest
    container_name: waf-prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./config/prometheus.yml:/etc/prometheus/prometheus.yml:ro
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
      - '--web.enable-lifecycle'
    networks:
      - waf-network
    profiles:
      - monitoring

  # Optional: Grafana for visualization
  grafana:
    image: grafana/grafana:latest
    container_name: waf-grafana
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
    volumes:
      - grafana-storage:/var/lib/grafana
      - ./config/grafana-datasources.yml:/etc/grafana/provisioning/datasources/datasources.yml:ro
      - ./config/grafana-dashboard.json:/var/lib/grafana/dashboards/waf-dashboard.json:ro
    networks:
      - waf-network
    profiles:
      - monitoring

networks:
  waf-network:
    driver: bridge

volumes:
  grafana-storage:
'''

with open("webapp-ml-waf/docker-compose.yml", "w") as f:
    f.write(docker_compose)

print("✅ Created Docker configuration files")